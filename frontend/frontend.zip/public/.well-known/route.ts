import { NextResponse } from 'next/server'

export async function GET() {
  // Crear el manifest usando las variables de entorno
  const manifest = {
    "name": "VendedoresApp",
    "icon": `${process.env.NEXT_PUBLIC_URL || 'http://localhost:3000'}/icon.svg`,
    "url": process.env.NEXT_PUBLIC_URL || 'http://localhost:3000',
    "description": "Conecta vendedores ambulantes con clientes en tiempo real",
    "accountAssociation": {
      "header": process.env.FARCASTER_HEADER || "",
      "payload": process.env.FARCASTER_PAYLOAD || "",
      "signature": process.env.FARCASTER_SIGNATURE || ""
    }
  }

  return NextResponse.json(manifest, {
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  })
}
